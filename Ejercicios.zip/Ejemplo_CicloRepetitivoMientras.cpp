/*DESCRIPCI�N:
ESTE PROGRAMA EN C++ CORRESPONDE AL SIGUIENTE ALGORITMO:
Este algoritmo recibe como entrada diez n�meros enteros y 
muestra como salida el promedio de ellos.*/

//DIRECTIVAS AL PRE-COMPILADOR
#include<iostream>

//ESPACIO DE NOMBRE
using namespace std; 

//FUNCION PRINCIPAL
int main()
//INICIO
{
//DECLARACI�N E INICIALIZACI�N DE VARIABLES
int numero;
float promedio;
int suma=0;
int contador=0;
const float cantidadTotal=10.0;
//PASOS
while(contador<cantidadTotal)
{
	cout<<"Ingresar un numero entero: ";
	cin>>numero;
	suma=suma+numero;
	contador=contador+1;
}
promedio=suma/cantidadTotal;
cout<<"El promedio es: "<<promedio;
return 0;
//FIN
}
